
package app.model;

public class Payload {


}
